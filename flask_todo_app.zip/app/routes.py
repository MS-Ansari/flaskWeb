from flask import Flask

def configure_routes(app):
    @app.route("/")
    def home():
        return "Hello, World!"
